import '@root/setEnvironment';
import { TgBot } from '@app/modules/tg-bot';

const bot = new TgBot();
bot.init();
