export const tgConfig = {
  TOKEN: process.env.TG_TOKEN || '',
  SESSION_DB_FILE: 'tg-session-db.json',
};
