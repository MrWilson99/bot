export const cryptomusConfig = {
  API_KEY: process.env.CRYPTOMUS_API_KEY,
  MERCHANT_ID: process.env.CRYPTOMUS_MERCHANT_ID,
  API_URL: 'https://api.cryptomus.com/v1',
};
